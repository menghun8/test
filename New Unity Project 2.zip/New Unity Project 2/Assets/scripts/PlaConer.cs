﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class PlaConer : NetworkBehaviour {

	public GameObject Bu_ZD;
	public Transform Bu_ZDWZ;


	
	// Update is called once per frame
	void Update () {

		if (isLocalPlayer == false) {
			return;
		}

		float h = Input.GetAxis ("Horizontal");
		float v = Input.GetAxis("Vertical");

		transform.Rotate(Vector3.up * h * 120 * Time.deltaTime);
		transform.Translate(Vector3.right * v * 3 * Time.deltaTime);

		if (Input.GetKeyDown(KeyCode.Space)) {
			CmdFire();
		}

	}


	public override void OnStartLocalPlayer()  {

		//(当角色被创建的时候)这个方法只会在本地角色那里调用
		GetComponent<MeshRenderer> ().material.color = Color.blue;

	
	}


	////////
	[Command]////////将以下代码 在客户端调用 服务器运行 必须在变量前加Cmd
	void CmdFire(){
		GameObject Bu = Instantiate (Bu_ZD, Bu_ZDWZ.position, Bu_ZDWZ.rotation) as GameObject;
		Bu.GetComponent<Rigidbody>().velocity = Bu.transform.right * 10;
		Destroy (Bu, 2);
	////////



		NetworkServer.Spawn(Bu);//生成指定的游戏物体(比如Bu)在所有的客户端
	}

}
