﻿using UnityEngine;
using System.Collections;

public class Hh : MonoBehaviour {

	public const int maxHh = 100;
	public int cur_DQXL = maxHh;

	public void TakeDammage(int damage) {
		cur_DQXL -= damage;
		if (cur_DQXL <= 0) {
			cur_DQXL = 0;
			Debug.Log ("Dead");
		}

	}
}
