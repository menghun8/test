﻿using UnityEngine;
using System.Collections;

public class Bu : MonoBehaviour {

	// Use this for initialization
	void OnCZDPZ(Collision col) {

		GameObject hit = col.gameObject;
		Hh Hh = hit.GetComponent<Hh>();

		if (Hh != null) {

			Hh.TakeDammage(10);

		}

		Destroy (this.gameObject);
	}
}
